M.I TECH NG HUB SMART CARD
Upload all files to a static HTTPS host to publish.
NFC: after publishing, write the public HTTPS website URL to a compatible NFC card/tag using an NFC-writing app. A physical NFC card is not included.
The MI logo uses a CSS 3D-style animation, not a physical hologram.
The OPay QR is the previously supplied payload and is not verified as an account-number transfer QR. Test safely; never confirm payment or share PIN/OTP.
